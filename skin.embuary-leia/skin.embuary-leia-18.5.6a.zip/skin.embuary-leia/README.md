# skin.embuary
Embuary is based on the web UI of Emby and has been developed for Emby-For-kodi User.
Please note that this skin is not 100% finished and it's in the alpha stage.

# Terms of use
With the installation of the skin you agree that you don't use it in combination with blacklisted and illegal Kodi add-ons.
I'm not associated with any available build and I won't give any support to blacklisted, banned or illegal third party addons.

# License
This work has been released under CC by-nc-nd 4.0.

You are allowed to:
- Change whatever if you want to use it for your your personal use, but don't share it to the public. That restriction also applies to public GitHub repositories.
- Fork and add your personal modifications if you don't change the addon title/name and keep my name as provider in the first place. The addon.xml has to include proper credits and the information that it's a fork. The license model cannot be changed.
- Modification tags behind the addon title are allowed. Example: ID "skin.embuary-moddedbyme" Name "Embuary Skin - Modded by me".
