# fTV Mosaic Screensaver
This screensaver imitates the Mosaic Screensaver of FireTV devices.
It uses posters and fanarts of the TV Show and Movie library.

It's made for Hitchers original fTV skin and for my fork with PVR support, but will also work on other skins.

(mine) fTV mod with PVR thread: http://forum.kodi.tv/showthread.php?tid=253058
(Hitchers) Original fTV skin thread: http://forum.kodi.tv/showthread.php?tid=207475



